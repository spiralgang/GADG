


                              SMC -
                     The State Machine Compiler


+ Installing statemap.h
-----------------------

NOTE: There is nothing to build - only a header file to install.
