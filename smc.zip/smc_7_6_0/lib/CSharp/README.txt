


                              SMC -
                     The State Machine Compiler


+ Building & Installing statemap.dll
------------------------------------

NOTE: This code only should be used to generate statemap.dll.
This dll should be used for both CSharp and VB.net applications.

statemap.dll is no longer provided by the SMC project. Users are
required to build statemap.dll on their system.
