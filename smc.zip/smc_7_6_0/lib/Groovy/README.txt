


                              SMC -
                     The State Machine Compiler


+ Building & Installing statemap.jar
------------------------------------

The Groovy "statemap.jar" is no longer provided but may be built
directly by going to the directory containing statemap.groovy
and:

$ groovyc statemap.groovy
$ java cvf statemap.jar statemap
