Statemap
========

INSTALLATION

Contains statemap-7.5.0.jar needed to build Java projects using
SMC state machine. Includes statemap-7.5.0-javadoc.jar which
contains the statemap API javadocs.

Source code used to build statemap-7.5.0.jar is also provided.
