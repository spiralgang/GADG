Statemap
========

INSTALLATION

NOTE: There is nothing to build - only a JavaScript file to install.
