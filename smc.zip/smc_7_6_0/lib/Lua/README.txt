Statemap
========

INSTALLATION

NOTE: There is nothing to build - only a Lua file to install.
