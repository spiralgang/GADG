statemap
========

INSTALLATION

To build this module, type the following:

   perl Makefile.PL

TEST

   perl test.pl


DOCUMENTATION

To generate the file statemap.html, type the following:

   pod2html --infile statemap.pm --outfile statemap.html

