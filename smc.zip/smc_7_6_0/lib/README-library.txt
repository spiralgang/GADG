SMC - The State Machine Compiler Library

Contains SMC header or library files need to compile an SMC-based
application in the desired target language. Download the
header/DLL/jar file required for the target language.
