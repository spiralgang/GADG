Statemap
========

INSTALLATION

NOTE: There is nothing to build - only a Ruby file to install:
statemap.rb

DOCUMENTATION

To generate the HTML files, type the following:

   rdoc statemap.rb

