


                              SMC -
                     The State Machine Compiler


+ Building & Installing statemap.jar
------------------------------------

The Scala "statemap.jar" is no longer provided but may be build
directly by going to the directory containing statemap.scala and:

$ scalac -d . statemap.scala
$ java cvf statemap.jar statemap
