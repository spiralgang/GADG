


                              SMC -
                     The State Machine Compiler


+ Installing statemap.tcl
-------------------------

NOTE: There is nothing to build - only installation. Place
      statemap.tcl in the appropriate lib directory so it can be
      found by the "package require" command.
