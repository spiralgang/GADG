


                              SMC -
                     The State Machine Compiler


+ Building & Installing statemap.dll
------------------------------------

THIS LIBRARY IS DEPRECATED.
The statemap.dll is generated from the CSharp implementation.
See smc/lib/CSharp for more information.
