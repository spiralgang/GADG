SMC - The State Machine Compiler 7.6.0 Tools

Contains SMC maven plug-in jar files, including source and
javadocs.
